public class modulusOperatorMI {
    
    public static void main(String[] args) {
        int num1 = 9, num2 = 8;
        int result;
        result = (num1 % num2);
        System.out.println("The remainder is: "+result);
    }
}
