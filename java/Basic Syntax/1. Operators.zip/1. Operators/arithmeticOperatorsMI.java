public class arithmeticOperatorsMI {

    public static void main(String[] args) {
        int  num2 = 15 ,num1 = 20;
        int sum, diff, quotient, product;
        
        //addition Operation
        sum = num1 + num2;
        //subtraction Operation
        diff = num1 - num2;
        //multiplication Operation
        product = num1 * num2;
        //Division Operation
        quotient = num1 / num2;
        System.out.println("First number is: "+num1 + " The second number is: "+num2);
        System.out.println("The sum is: "+sum);
        System.out.println("The differences is: "+diff);
        System.out.println("The product is: "+product);
        System.out.println("The qoutient is: "+quotient);

    }
}